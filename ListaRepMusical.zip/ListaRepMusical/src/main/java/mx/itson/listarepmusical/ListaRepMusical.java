

package mx.itson.listarepmusical;

/**
 *
 * @author Jairo G. Rodriguez Hernandez 00000213248
 */
public class ListaRepMusical {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
